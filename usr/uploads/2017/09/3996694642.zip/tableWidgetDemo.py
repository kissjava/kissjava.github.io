# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'tableWidgetDemo.ui'
#
# Created by: PyQt5 UI code generator 5.6
#
# WARNING! All changes made in this file will be lost!

from PyQt5 import QtCore, QtGui, QtWidgets

class Ui_MainWindow(object):
    def setupUi(self, MainWindow):
        MainWindow.setObjectName("MainWindow")
        MainWindow.resize(800, 600)
        self.centralwidget = QtWidgets.QWidget(MainWindow)
        self.centralwidget.setObjectName("centralwidget")
        self.tableWidget = QtWidgets.QTableWidget(self.centralwidget)
        self.tableWidget.setGeometry(QtCore.QRect(0, 0, 801, 541))
        self.tableWidget.setRowCount(5)
        self.tableWidget.setColumnCount(11)
        self.tableWidget.setObjectName("tableWidget")
        self.horizontalLayoutWidget = QtWidgets.QWidget(self.centralwidget)
        self.horizontalLayoutWidget.setGeometry(QtCore.QRect(0, 540, 801, 31))
        self.horizontalLayoutWidget.setObjectName("horizontalLayoutWidget")
        self.horizontalLayout = QtWidgets.QHBoxLayout(self.horizontalLayoutWidget)
        self.horizontalLayout.setContentsMargins(0, 0, 0, 0)
        self.horizontalLayout.setObjectName("horizontalLayout")
        self.btnLoad = QtWidgets.QPushButton(self.horizontalLayoutWidget)
        self.btnLoad.setObjectName("btnLoad")
        self.horizontalLayout.addWidget(self.btnLoad)
        self.btnPre = QtWidgets.QPushButton(self.horizontalLayoutWidget)
        self.btnPre.setObjectName("btnPre")
        self.horizontalLayout.addWidget(self.btnPre)
        self.btnNext = QtWidgets.QPushButton(self.horizontalLayoutWidget)
        self.btnNext.setObjectName("btnNext")
        self.horizontalLayout.addWidget(self.btnNext)
        self.btnDetail = QtWidgets.QPushButton(self.horizontalLayoutWidget)
        self.btnDetail.setObjectName("btnDetail")
        self.horizontalLayout.addWidget(self.btnDetail)
        MainWindow.setCentralWidget(self.centralwidget)
        self.statusbar = QtWidgets.QStatusBar(MainWindow)
        self.statusbar.setObjectName("statusbar")
        MainWindow.setStatusBar(self.statusbar)

        self.retranslateUi(MainWindow)
        QtCore.QMetaObject.connectSlotsByName(MainWindow)

    def retranslateUi(self, MainWindow):
        _translate = QtCore.QCoreApplication.translate
        MainWindow.setWindowTitle(_translate("MainWindow", "MainWindow"))
        self.btnLoad.setText(_translate("MainWindow", "Load"))
        self.btnPre.setText(_translate("MainWindow", "《Pre"))
        self.btnNext.setText(_translate("MainWindow", "Next》"))
        self.btnDetail.setText(_translate("MainWindow", "Detail"))
