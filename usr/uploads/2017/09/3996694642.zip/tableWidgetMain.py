from PyQt5 import QtWidgets, QtCore
import sqlite3

from tableWidgetDemo import Ui_MainWindow

class Window(QtWidgets.QMainWindow):
    def  __init__(self, parent=None):
        super(Window, self).__init__(parent=parent)
        self.ui = Ui_MainWindow()
        self.ui.setupUi(self)
        self.initStyle()
        self.initConn()

        self.currentPage = 1

        self.ui.btnLoad.clicked.connect(lambda :self.loadData(1))
        self.ui.btnDetail.clicked.connect(self.showDetail)
        self.ui.btnPre.clicked.connect(lambda : self.loadData(self.currentPage - 1))
        self.ui.btnNext.clicked.connect(lambda : self.loadData(self.currentPage + 1))

    def closeEvent(self, event):
        self.connection.close()
        event.accept()

    def initStyle(self):
        horizontalHeader = ['CustomerID','FirstName','LastName','Company','Address','City','State','国籍','邮编','电话',"Action"]
        self.ui.tableWidget.setHorizontalHeaderLabels(horizontalHeader)

    def initConn(self):
        self.connection = sqlite3.connect("mydb.db")
        self.cur = self.connection.cursor()

    def saveLine(self,id):
        print("saveLine id %d" % id)

    def delLine(self,id):
        print("delLine id %d" % id)

    def createInnerButton(self,id):
        widget = QtWidgets.QWidget()
        saveBtn = QtWidgets.QPushButton("Save")
        saveBtn.setStyleSheet("background-color:DarkSeaGreen;border-style:outset;border-radius:3px")
        saveBtn.setFixedSize(40,14)
        saveBtn.clicked.connect(lambda: self.saveLine(id))

        delBtn = QtWidgets.QPushButton("Del")
        delBtn.setStyleSheet("background-color:LightCoral;border-style:outset;border-radius:3px")
        delBtn.setFixedSize(40,14)
        delBtn.clicked.connect(lambda: self.delLine(id))

        layout = QtWidgets.QHBoxLayout()
        layout.addWidget(saveBtn)
        layout.addWidget(delBtn)
        widget.setLayout(layout)
        return widget

    def showDetail(self):
        select = self.ui.tableWidget.selectedItems()
        if select:
            print(select)
            try:
                print(select[0].text())
                rs = ",".join([i.text() for i in select])
                QtWidgets.QMessageBox.about(self, '你选择的项目', rs)
            except Exception as e:
                print(e)
        else:
            print("Nothing.")


    def loadData(self, page = 1):

        if page < 1:
            QtWidgets.QMessageBox.about(self, '提示', "提示：已经到第一页了\t")
            return

        pageSize = 16
        offset = (page - 1) * pageSize
        query = "SELECT CustomerID,FirstName,LastName,Company,Address,City,State,Country,PostalCode,Phone FROM customers"
        query += " limit %d offset %d" % (pageSize, offset)
        self.cur.execute(query)

        result = self.cur.fetchall()

        if len(result) == 0:
            QtWidgets.QMessageBox.about(self, '提示', "提示：没有下一页了\t")
            return

        self.currentPage = page

        self.ui.tableWidget.setRowCount(0)
        for row_number, row_data in enumerate(result):
            self.ui.tableWidget.insertRow(row_number)
            for colum_number, data in enumerate(row_data):
                self.ui.tableWidget.setItem(row_number, colum_number, QtWidgets.QTableWidgetItem(str(data)))

            temp = QtWidgets.QTableWidgetItem()
            temp.setFlags(QtCore.Qt.ItemIsEnabled)
            self.ui.tableWidget.setItem(row_number,10,temp)

            actionItem = self.createInnerButton(row_data[0])
            self.ui.tableWidget.setCellWidget(row_number,10,actionItem)


if __name__ == "__main__":
    import sys
    app = QtWidgets.QApplication(sys.argv)
    w = Window()
    w.show()
    sys.exit(app.exec_())
